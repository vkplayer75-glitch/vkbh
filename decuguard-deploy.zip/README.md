# DecuGuard dashboard: deployment

`public/index.html` is the complete, unchanged dashboard (single file, no build step).
Only head metadata (description, theme colour, favicon, font preconnect) was added.

## Deploy to Firebase Hosting
1. `npm i -g firebase-tools && firebase login`
2. In this folder: `firebase init` (choose Hosting + Realtime Database, keep `public` and existing files, do NOT overwrite index.html)
3. Firebase console: enable **Authentication → Anonymous**, and create a **Realtime Database**.
4. `firebase deploy`

Other hosts (Netlify, Vercel, GitHub Pages, any static server): upload `public/index.html`.

## Connect
Open the site → **Cloud settings** → paste your web-app config (needs `databaseURL`), set Device ID
(must match the ESP-12E sketch, default `bed-01`), choose Anonymous sign-in, press Connect.
To skip the dialog, paste the config into `FIREBASE_CONFIG` near the top of the script.

## Database paths (`/devices/<id>/`)
- `latest` (ESP writes): `p{shL,shR,sacrum,heelL,heelR}` 0-100, `edge{l,r}` cm, `pir{bed,room}`, `rssi`, `up`
- `history` (ESP writes, optional): same fields plus `ts` (ms)
- `cmd` (dashboard writes): `action` = voice_turn | voice_stay | buzzer | silence | volume, `value`, `id`, `ts`
- `settings`, `lastTurn`, `alerts`, `acks` (dashboard writes)

## Security
The provided rules allow any signed-in (including anonymous) user to read/write devices.
For real patient use, restrict to specific UIDs or use email auth, and serve over HTTPS only.
This is a monitoring aid, not a certified medical device.
